//
//  main.m
//  godot_ios
//
//  Created by Ariel m on 2/14/14.
//  Copyright (c) 2014 Okam. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
